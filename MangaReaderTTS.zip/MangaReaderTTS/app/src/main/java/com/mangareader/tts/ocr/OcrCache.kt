package com.mangareader.tts.ocr

import android.util.LruCache

/**
 * Cache ผล OCR ตาม hash ของภาพ
 * ลดค่าใช้จ่าย cloud และเพิ่มความเร็ว
 */
object OcrCache {

    private const val MAX_ENTRIES = 30

    private val cache = object : LruCache<String, List<TextBlock>>(MAX_ENTRIES) {
        override fun sizeOf(key: String, value: List<TextBlock>): Int = 1
    }

    fun get(hash: String): List<TextBlock>? = cache.get(hash)

    fun put(hash: String, blocks: List<TextBlock>) {
        cache.put(hash, blocks)
    }

    fun clear() {
        cache.evictAll()
    }
}
