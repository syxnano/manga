package com.mangareader.tts.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mangareader.tts.data.AppSettings

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onStartService: () -> Unit,
    onStopService: () -> Unit,
    onOpenBatterySettings: () -> Unit,
    onOpenOverlaySettings: () -> Unit
) {
    var apiKey by remember { mutableStateOf(AppSettings.googleVisionApiKey) }
    var proxyUrl by remember { mutableStateOf(AppSettings.proxyUrl) }
    var ocrEngine by remember { mutableStateOf(AppSettings.ocrEngine) }
    var readingOrder by remember { mutableStateOf(AppSettings.readingOrder) }
    var filterSfx by remember { mutableStateOf(AppSettings.filterSfx) }
    var convert555 by remember { mutableStateOf(AppSettings.convert555) }
    var showCorrection by remember { mutableStateOf(AppSettings.showCorrectionDialog) }
    var speechRate by remember { mutableStateOf(AppSettings.ttsSpeechRate) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Manga Reader TTS") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .verticalScroll(rememberScrollState())
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // === เริ่มใช้งาน ===
            Text("เริ่มใช้งาน", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Button(
                onClick = onStartService,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("เริ่มปุ่มลอย + ขอสิทธิ์จับภาพ")
            }

            OutlinedButton(
                onClick = onStopService,
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Default.Stop, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("หยุดบริการ")
            }

            HorizontalDivider()

            // === สิทธิ์ ===
            Text("สิทธิ์ที่จำเป็น", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            OutlinedButton(onClick = onOpenOverlaySettings, modifier = Modifier.fillMaxWidth()) {
                Text("เปิดการตั้งค่า Overlay (แสดงทับแอปอื่น)")
            }

            OutlinedButton(onClick = onOpenBatterySettings, modifier = Modifier.fillMaxWidth()) {
                Text("ปิดการจำกัดแบตเตอรี่ (สำคัญมาก)")
            }

            Text(
                "โดยเฉพาะ Xiaomi, Oppo, Vivo, Huawei, Samsung ต้องปิด Battery Optimization และเปิด Autostart",
                style = MaterialTheme.typography.bodySmall
            )

            HorizontalDivider()

            // === OCR ===
            Text("OCR Engine", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Text(
                "ไม่ใส่ API Key ก็ใช้ได้ → เลือก Offline",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.secondary
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = ocrEngine == "offline",
                    onClick = {
                        ocrEngine = "offline"
                        AppSettings.ocrEngine = "offline"
                    }
                )
                Text("Offline (Tesseract) — ไม่ต้องใช้ API Key")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = ocrEngine == "cloud",
                    onClick = {
                        ocrEngine = "cloud"
                        AppSettings.ocrEngine = "cloud"
                    }
                )
                Text("Cloud (Google Vision) — แม่นยำกว่า แต่ต้องมี Key")
            }

            if (ocrEngine == "cloud") {
                OutlinedTextField(
                    value = apiKey,
                    onValueChange = {
                        apiKey = it
                        AppSettings.googleVisionApiKey = it
                    },
                    label = { Text("Google Vision API Key") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = proxyUrl,
                    onValueChange = {
                        proxyUrl = it
                        AppSettings.proxyUrl = it
                    },
                    label = { Text("Proxy URL (ถ้ามี)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Text(
                    "⚠ โหมด Cloud จะส่งภาพส่วนที่เลือกออกนอกเครื่อง",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.error
                )
            } else {
                Text(
                    "โหมด Offline ทำงานในเครื่องทั้งหมด ไม่ส่งภาพออก\nต้องมีไฟล์ tha.traineddata (ดูวิธีใน README)",
                    style = MaterialTheme.typography.bodySmall
                )
            }

            HorizontalDivider()

            // === การอ่าน ===
            Text("การอ่าน", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = readingOrder == "ltr",
                    onClick = {
                        readingOrder = "ltr"
                        AppSettings.readingOrder = "ltr"
                    }
                )
                Text("ซ้าย → ขวา")
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = readingOrder == "rtl",
                    onClick = {
                        readingOrder = "rtl"
                        AppSettings.readingOrder = "rtl"
                    }
                )
                Text("ขวา → ซ้าย (มังงะญี่ปุ่น)")
            }

            Text("ความเร็ว TTS: %.1fx".format(speechRate))
            Slider(
                value = speechRate,
                onValueChange = {
                    speechRate = it
                    AppSettings.ttsSpeechRate = it
                },
                valueRange = 0.5f..2.0f
            )

            HorizontalDivider()

            // === กรองข้อความ ===
            Text("ประมวลผลข้อความ", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("กรอง SFX / ลายน้ำ / เครดิต")
                Switch(checked = filterSfx, onCheckedChange = {
                    filterSfx = it
                    AppSettings.filterSfx = it
                })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("แปลง 555 เป็นเสียงหัวเราะ")
                Switch(checked = convert555, onCheckedChange = {
                    convert555 = it
                    AppSettings.convert555 = it
                })
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("แสดงหน้าต่างแก้ข้อความก่อนอ่าน")
                Switch(checked = showCorrection, onCheckedChange = {
                    showCorrection = it
                    AppSettings.showCorrectionDialog = it
                })
            }

            Spacer(Modifier.height(24.dp))

            Text(
                "วิธีใช้:\n1. กด \"เริ่มปุ่มลอย\"\n2. อนุญาต Overlay + จับภาพหน้าจอ\n3. เปิดมังงะในแอปอื่น\n4. แตะปุ่มลอยเพื่ออ่าน\n5. กดค้างปุ่มลอยเพื่อสลับโหมด (TAP / CROP / FULL)",
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}
