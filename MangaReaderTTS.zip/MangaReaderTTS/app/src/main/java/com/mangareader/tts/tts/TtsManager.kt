package com.mangareader.tts.tts

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.mangareader.tts.data.AppSettings
import java.util.Locale
import java.util.UUID

/**
 * จัดการ Android TextToSpeech + คิวการอ่าน
 * ออกแบบให้เสียบ Cloud TTS เพิ่มได้ในภายหลัง
 */
class TtsManager(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isReady = false
    private val queue = ArrayDeque<String>()
    private var isPaused = false
    private var currentIndex = -1

    var onUtteranceStart: ((String) -> Unit)? = null
    var onUtteranceDone: ((String) -> Unit)? = null
    var onQueueFinished: (() -> Unit)? = null
    var onError: ((String) -> Unit)? = null

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale("th", "TH"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                Log.w("TtsManager", "Thai language not fully supported, trying default")
                tts?.language = Locale.getDefault()
            }
            tts?.setSpeechRate(AppSettings.ttsSpeechRate)
            tts?.setPitch(AppSettings.ttsPitch)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    utteranceId?.let { onUtteranceStart?.invoke(it) }
                }

                override fun onDone(utteranceId: String?) {
                    utteranceId?.let { onUtteranceDone?.invoke(it) }
                    playNext()
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onError?.invoke(utteranceId ?: "unknown")
                    playNext()
                }
            })
            isReady = true
        } else {
            onError?.invoke("TTS initialization failed")
        }
    }

    fun speak(texts: List<String>) {
        if (!isReady) {
            onError?.invoke("TTS ยังไม่พร้อม")
            return
        }
        stop()
        queue.clear()
        queue.addAll(texts.filter { it.isNotBlank() })
        currentIndex = -1
        isPaused = false
        playNext()
    }

    fun speakSingle(text: String) {
        speak(listOf(text))
    }

    private fun playNext() {
        if (isPaused) return
        if (queue.isEmpty()) {
            onQueueFinished?.invoke()
            return
        }
        currentIndex++
        if (currentIndex >= queue.size) {
            onQueueFinished?.invoke()
            return
        }
        val text = queue[currentIndex]
        val utteranceId = UUID.randomUUID().toString()
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun pause() {
        isPaused = true
        tts?.stop()
    }

    fun resume() {
        if (!isPaused) return
        isPaused = false
        // เล่นต่อจากประโยคปัจจุบัน
        if (currentIndex in queue.indices) {
            currentIndex-- // ให้ playNext เพิ่มกลับ
            playNext()
        }
    }

    fun skip() {
        tts?.stop()
        playNext()
    }

    fun previous() {
        tts?.stop()
        if (currentIndex > 0) {
            currentIndex -= 2 // playNext จะ +1
            playNext()
        }
    }

    fun stop() {
        isPaused = false
        currentIndex = -1
        queue.clear()
        tts?.stop()
    }

    fun setSpeechRate(rate: Float) {
        AppSettings.ttsSpeechRate = rate
        tts?.setSpeechRate(rate)
    }

    fun setPitch(pitch: Float) {
        AppSettings.ttsPitch = pitch
        tts?.setPitch(pitch)
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        isReady = false
    }

    fun isSpeaking(): Boolean = tts?.isSpeaking == true
}
