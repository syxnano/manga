package com.mangareader.tts

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.mangareader.tts.data.AppSettings

class MangaReaderApp : Application() {

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        AppSettings.init(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Manga Reader Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "แสดงสถานะปุ่มลอยและบริการจับภาพ"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "manga_reader_service"
    }
}
