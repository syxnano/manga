package com.mangareader.tts.text

import com.mangareader.tts.data.AppSettings
import com.mangareader.tts.ocr.TextBlock

data class ProcessOptions(
    val filterSfx: Boolean = true,
    val convert555: Boolean = true,
    val mergeBrokenLines: Boolean = true
)

object TextProcessor {

    // คำ/รูปแบบที่มักเป็น SFX หรือ watermark
    private val sfxPatterns = listOf(
        Regex("""^[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+$"""),
        Regex("""(?i)(sfx|sound|effect|www\.|http|\.com|\.net|scanlated|translated by|แปลโดย|เครดิต)"""),
        Regex("""^[ก-ฮ]{1,3}$""") // ตัวอักษรเดี่ยวสั้น ๆ ที่มักเป็นเสียงประกอบ
    )

    fun process(blocks: List<TextBlock>, options: ProcessOptions = defaultOptions()): List<String> {
        if (blocks.isEmpty()) return emptyList()

        // เรียงตามตำแหน่ง (จะถูก override โดย ReadingOrder ภายนอก)
        val sorted = blocks.sortedWith(compareBy({ it.boundingBox.top }, { it.boundingBox.left }))

        val texts = sorted.map { it.text.trim() }
            .filter { it.isNotBlank() }
            .map { cleanText(it, options) }
            .filter { !shouldFilter(it, options) }

        val merged = if (options.mergeBrokenLines) mergeBrokenSentences(texts) else texts

        return splitIntoSpeakableUnits(merged)
    }

    private fun defaultOptions() = ProcessOptions(
        filterSfx = AppSettings.filterSfx,
        convert555 = AppSettings.convert555
    )

    private fun cleanText(raw: String, options: ProcessOptions): String {
        var text = raw
            .replace(Regex("""\s+"""), " ")
            .replace(Regex("""[\u0000-\u001F\u007F]"""), "")
            .trim()

        if (options.convert555) {
            // 555, 5555, 55555 → ฮ่า ๆ ๆ
            text = text.replace(Regex("""5{3,}""")) { match ->
                val count = match.value.length
                "ฮ่า" + " ๆ".repeat((count - 2).coerceAtMost(4))
            }
        }

        // จัดการ ๆ ที่ซ้ำผิดปกติ
        text = text.replace(Regex("""ๆ{3,}"""), "ๆ")

        return text
    }

    private fun shouldFilter(text: String, options: ProcessOptions): Boolean {
        if (!options.filterSfx) return false
        if (text.length <= 1) return true
        return sfxPatterns.any { it.containsMatchIn(text) }
    }

    /**
     * รวมบรรทัดที่ถูกตัดกลางประโยค (heuristic ง่าย ๆ)
     */
    private fun mergeBrokenSentences(lines: List<String>): List<String> {
        if (lines.isEmpty()) return emptyList()
        val result = mutableListOf<String>()
        var current = StringBuilder(lines[0])

        for (i in 1 until lines.size) {
            val next = lines[i]
            val prevEndsWithSentence = current.lastOrNull() in listOf('.', '!', '?', '।', '…')
            val nextStartsLower = next.firstOrNull()?.isLowerCase() == true ||
                    next.firstOrNull() in 'ก'..'ฮ'

            if (!prevEndsWithSentence && nextStartsLower && current.length < 80) {
                current.append(" ").append(next)
            } else {
                result.add(current.toString().trim())
                current = StringBuilder(next)
            }
        }
        result.add(current.toString().trim())
        return result.filter { it.isNotBlank() }
    }

    /**
     * แยกเป็นประโยคสั้น ๆ ให้อ่านเป็นจังหวะ
     */
    private fun splitIntoSpeakableUnits(texts: List<String>): List<String> {
        val units = mutableListOf<String>()
        for (text in texts) {
            // แยกตามวรรคตอนไทย/อังกฤษ
            val parts = text.split(Regex("""(?<=[.!?…])\s+|(?<=\n)"""))
                .map { it.trim() }
                .filter { it.isNotBlank() }
            units.addAll(parts)
        }
        return units
    }
}
