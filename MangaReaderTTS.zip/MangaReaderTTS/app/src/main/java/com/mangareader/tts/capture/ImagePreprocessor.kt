package com.mangareader.tts.capture

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import java.security.MessageDigest

object ImagePreprocessor {

    private const val MAX_DIMENSION = 1280

    /**
     * ย่อขนาด + เพิ่มความคมชัดเล็กน้อย ก่อนส่ง OCR
     * คืน Bitmap ใหม่ (ต้นทางไม่ถูก recycle)
     */
    fun prepareForOcr(source: Bitmap): Bitmap {
        val scaled = scaleDown(source)
        return enhanceSharpness(scaled).also {
            if (it != scaled && scaled != source) scaled.recycle()
        }
    }

    private fun scaleDown(bitmap: Bitmap): Bitmap {
        val maxSide = maxOf(bitmap.width, bitmap.height)
        if (maxSide <= MAX_DIMENSION) return bitmap

        val scale = MAX_DIMENSION.toFloat() / maxSide
        val newW = (bitmap.width * scale).toInt()
        val newH = (bitmap.height * scale).toInt()
        return Bitmap.createScaledBitmap(bitmap, newW, newH, true)
    }

    private fun enhanceSharpness(bitmap: Bitmap): Bitmap {
        // Unsharp mask แบบง่าย (เพิ่ม contrast นิดหน่อย)
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config ?: Bitmap.Config.ARGB_8888)
        val canvas = Canvas(result)
        val paint = Paint()
        val cm = ColorMatrix(floatArrayOf(
            1.1f, 0f, 0f, 0f, -10f,
            0f, 1.1f, 0f, 0f, -10f,
            0f, 0f, 1.1f, 0f, -10f,
            0f, 0f, 0f, 1f, 0f
        ))
        paint.colorFilter = ColorMatrixColorFilter(cm)
        canvas.drawBitmap(bitmap, 0f, 0f, paint)
        return result
    }

    /**
     * สร้าง hash สำหรับ cache (ใช้ pixel data ของภาพที่ย่อแล้ว)
     */
    fun computeHash(bitmap: Bitmap): String {
        val buffer = java.nio.ByteBuffer.allocate(bitmap.byteCount)
        bitmap.copyPixelsToBuffer(buffer)
        val digest = MessageDigest.getInstance("SHA-256")
        val hash = digest.digest(buffer.array())
        return hash.joinToString("") { "%02x".format(it) }
    }
}
