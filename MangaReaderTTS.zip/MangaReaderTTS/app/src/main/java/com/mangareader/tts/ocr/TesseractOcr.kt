package com.mangareader.tts.ocr

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/**
 * Offline OCR ด้วย Tesseract
 *
 * หมายเหตุ: เพื่อให้ APK เล็ก เราไม่ฝัง tessdata ไว้ในโปรเจกต์
 * ผู้ใช้ต้องดาวน์โหลดไฟล์ tha.traineddata มาวางใน filesDir/tessdata เอง
 * หรือเพิ่ม dependency tess-two / tesseract4android แล้ว implement จริง
 *
 * ตอนนี้เป็น stub ที่คืนค่าว่าง + log เตือน
 */
class TesseractOcr(private val context: Context) : OcrEngine {

    private val tessDataPath: String
        get() = File(context.filesDir, "tessdata").absolutePath

    override fun getName(): String = "Tesseract (Offline)"

    override fun isAvailable(): Boolean {
        val trainedData = File(tessDataPath, "tha.traineddata")
        return trainedData.exists()
    }

    override suspend fun recognize(bitmap: Bitmap, language: String): List<TextBlock> =
        withContext(Dispatchers.IO) {
            if (!isAvailable()) {
                Log.w("TesseractOcr", "tha.traineddata not found at $tessDataPath")
                return@withContext emptyList()
            }

            // TODO: ใส่ implementation จริงด้วย tess-two หรือ tesseract4android
            // ตัวอย่างแนวทาง:
            // val tess = TessBaseAPI()
            // tess.init(tessDataPath, "tha")
            // tess.setImage(bitmap)
            // val text = tess.utF8Text
            // tess.end()
            // แล้ว parse เป็น TextBlock

            Log.i("TesseractOcr", "Tesseract offline is not fully implemented in this skeleton")
            emptyList()
        }
}
