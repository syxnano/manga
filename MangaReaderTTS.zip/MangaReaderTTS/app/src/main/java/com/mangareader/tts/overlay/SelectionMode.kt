package com.mangareader.tts.overlay

enum class SelectionMode {
    TAP,        // แตะที่บับเบิล
    CROP,       // ลากกรอบเอง
    FULL_SCREEN // อ่านทั้งหน้าจอ
}
