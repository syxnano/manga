package com.mangareader.tts.text

import com.mangareader.tts.data.AppSettings
import com.mangareader.tts.ocr.TextBlock

object ReadingOrder {

    fun sort(blocks: List<TextBlock>): List<TextBlock> {
        return when (AppSettings.readingOrder) {
            "rtl" -> sortRtl(blocks)
            else -> sortLtr(blocks)
        }
    }

    /** บนลงล่าง แล้วซ้ายไปขวา */
    private fun sortLtr(blocks: List<TextBlock>): List<TextBlock> {
        return blocks.sortedWith(
            compareBy(
                { it.boundingBox.top / 40 }, // group by approximate row
                { it.boundingBox.left }
            )
        )
    }

    /** บนลงล่าง แล้วขวาไปซ้าย (มังงะญี่ปุ่นหลายเรื่อง) */
    private fun sortRtl(blocks: List<TextBlock>): List<TextBlock> {
        return blocks.sortedWith(
            compareBy(
                { it.boundingBox.top / 40 },
                { -it.boundingBox.left }
            )
        )
    }
}
