package com.mangareader.tts.util

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

/**
 * รับ BOOT_COMPLETED เพื่อให้ผู้ใช้สามารถตั้งให้เปิดบริการอัตโนมัติได้
 * (ต้องขออนุญาตและเปิดใช้งานเองใน Settings)
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            Log.i("BootReceiver", "Device booted - service not auto-started for privacy")
            // ไม่เปิด service อัตโนมัติเพื่อความเป็นส่วนตัว
            // ผู้ใช้ต้องเปิดจากแอปเอง
        }
    }
}
