package com.mangareader.tts.ocr

import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Base64
import com.mangareader.tts.data.AppSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

/**
 * Google Cloud Vision OCR
 * ผู้ใช้ต้องกรอก API Key เอง หรือใช้ proxy
 */
class GoogleVisionOcr : OcrEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    override fun getName(): String = "Google Cloud Vision"

    override fun isAvailable(): Boolean {
        return AppSettings.googleVisionApiKey.isNotBlank() || AppSettings.proxyUrl.isNotBlank()
    }

    override suspend fun recognize(bitmap: Bitmap, language: String): List<TextBlock> =
        withContext(Dispatchers.IO) {
            if (!AppSettings.canUseOcrToday()) {
                throw IllegalStateException("เกินขีดจำกัดการใช้งาน OCR รายวัน")
            }

            val base64 = bitmapToBase64(bitmap)
            val requestJson = buildRequestJson(base64, language)

            val url = if (AppSettings.proxyUrl.isNotBlank()) {
                AppSettings.proxyUrl
            } else {
                "https://vision.googleapis.com/v1/images:annotate?key=${AppSettings.googleVisionApiKey}"
            }

            val body = requestJson.toRequestBody("application/json".toMediaType())
            val request = Request.Builder()
                .url(url)
                .post(body)
                .build()

            client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) {
                    throw Exception("Vision API error: ${response.code} ${response.message}")
                }
                val json = response.body?.string() ?: throw Exception("Empty response")
                parseResponse(json).also {
                    AppSettings.incrementOcrCount()
                }
            }
        }

    private fun bitmapToBase64(bitmap: Bitmap): String {
        val stream = ByteArrayOutputStream()
        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, stream)
        return Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
    }

    private fun buildRequestJson(base64: String, language: String): String {
        val image = JSONObject().put("content", base64)
        val feature = JSONObject()
            .put("type", "DOCUMENT_TEXT_DETECTION")
            .put("maxResults", 50)
        val imageContext = JSONObject()
            .put("languageHints", JSONArray().put(language))

        val request = JSONObject()
            .put("image", image)
            .put("features", JSONArray().put(feature))
            .put("imageContext", imageContext)

        return JSONObject()
            .put("requests", JSONArray().put(request))
            .toString()
    }

    private fun parseResponse(json: String): List<TextBlock> {
        val root = JSONObject(json)
        val responses = root.optJSONArray("responses") ?: return emptyList()
        if (responses.length() == 0) return emptyList()

        val first = responses.getJSONObject(0)
        val fullText = first.optJSONObject("fullTextAnnotation") ?: return emptyList()
        val pages = fullText.optJSONArray("pages") ?: return emptyList()

        val blocks = mutableListOf<TextBlock>()

        for (p in 0 until pages.length()) {
            val page = pages.getJSONObject(p)
            val pageBlocks = page.optJSONArray("blocks") ?: continue
            for (b in 0 until pageBlocks.length()) {
                val block = pageBlocks.getJSONObject(b)
                val paragraphs = block.optJSONArray("paragraphs") ?: continue
                val sb = StringBuilder()
                var minX = Int.MAX_VALUE
                var minY = Int.MAX_VALUE
                var maxX = 0
                var maxY = 0

                for (para in 0 until paragraphs.length()) {
                    val paragraph = paragraphs.getJSONObject(para)
                    val words = paragraph.optJSONArray("words") ?: continue
                    for (w in 0 until words.length()) {
                        val word = words.getJSONObject(w)
                        val symbols = word.optJSONArray("symbols") ?: continue
                        for (s in 0 until symbols.length()) {
                            val symbol = symbols.getJSONObject(s)
                            sb.append(symbol.optString("text", ""))
                            val vertices = symbol.optJSONObject("boundingBox")
                                ?.optJSONArray("vertices")
                            if (vertices != null) {
                                for (v in 0 until vertices.length()) {
                                    val vertex = vertices.getJSONObject(v)
                                    val x = vertex.optInt("x", 0)
                                    val y = vertex.optInt("y", 0)
                                    minX = minOf(minX, x)
                                    minY = minOf(minY, y)
                                    maxX = maxOf(maxX, x)
                                    maxY = maxOf(maxY, y)
                                }
                            }
                        }
                        sb.append(" ")
                    }
                    sb.append("\n")
                }

                val text = sb.toString().trim()
                if (text.isNotBlank()) {
                    blocks.add(
                        TextBlock(
                            text = text,
                            boundingBox = Rect(minX, minY, maxX, maxY)
                        )
                    )
                }
            }
        }
        return blocks
    }
}
