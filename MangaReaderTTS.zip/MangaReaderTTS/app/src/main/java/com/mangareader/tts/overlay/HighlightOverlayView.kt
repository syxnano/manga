package com.mangareader.tts.overlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.View
import com.mangareader.tts.ocr.TextBlock

/**
 * วาดกรอบไฮไลต์ข้อความที่ตรวจพบ
 */
class HighlightOverlayView(
    context: Context,
    private val blocks: List<TextBlock>
) : View(context) {

    private val paint = Paint().apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = 0xAA00E676.toInt()
        isAntiAlias = true
    }

    private val fillPaint = Paint().apply {
        style = Paint.Style.FILL
        color = 0x2200E676.toInt()
        isAntiAlias = true
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        for (block in blocks) {
            val rect = RectF(
                block.boundingBox.left.toFloat(),
                block.boundingBox.top.toFloat(),
                block.boundingBox.right.toFloat(),
                block.boundingBox.bottom.toFloat()
            )
            canvas.drawRoundRect(rect, 8f, 8f, fillPaint)
            canvas.drawRoundRect(rect, 8f, 8f, paint)
        }
    }
}
