package com.mangareader.tts.data

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

object AppSettings {

    private lateinit var prefs: SharedPreferences
    private lateinit var securePrefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences("manga_reader_prefs", Context.MODE_PRIVATE)

        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        securePrefs = EncryptedSharedPreferences.create(
            context,
            "manga_reader_secure",
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    // === OCR ===
    // ค่าเริ่มต้น: offline (ไม่ต้องใส่ API Key)
    // ถ้าผู้ใช้ใส่ API Key แล้วอยากใช้ cloud ให้เปลี่ยนเองใน Settings
    var ocrEngine: String
        get() = prefs.getString("ocr_engine", "offline") ?: "offline"
        set(value) = prefs.edit().putString("ocr_engine", value).apply()

    var googleVisionApiKey: String
        get() = securePrefs.getString("vision_api_key", "") ?: ""
        set(value) = securePrefs.edit().putString("vision_api_key", value).apply()

    var proxyUrl: String
        get() = prefs.getString("proxy_url", "") ?: ""
        set(value) = prefs.edit().putString("proxy_url", value).apply()

    var dailyOcrLimit: Int
        get() = prefs.getInt("daily_ocr_limit", 100)
        set(value) = prefs.edit().putInt("daily_ocr_limit", value).apply()

    var todayOcrCount: Int
        get() = prefs.getInt("today_ocr_count", 0)
        set(value) = prefs.edit().putInt("today_ocr_count", value).apply()

    var lastOcrDate: String
        get() = prefs.getString("last_ocr_date", "") ?: ""
        set(value) = prefs.edit().putString("last_ocr_date", value).apply()

    // === Reading Order ===
    var readingOrder: String
        get() = prefs.getString("reading_order", "ltr") ?: "ltr" // ltr / rtl
        set(value) = prefs.edit().putString("reading_order", value).apply()

    // === TTS ===
    var ttsSpeechRate: Float
        get() = prefs.getFloat("tts_rate", 1.0f)
        set(value) = prefs.edit().putFloat("tts_rate", value).apply()

    var ttsPitch: Float
        get() = prefs.getFloat("tts_pitch", 1.0f)
        set(value) = prefs.edit().putFloat("tts_pitch", value).apply()

    // === Text Processing ===
    var filterSfx: Boolean
        get() = prefs.getBoolean("filter_sfx", true)
        set(value) = prefs.edit().putBoolean("filter_sfx", value).apply()

    var showCorrectionDialog: Boolean
        get() = prefs.getBoolean("show_correction", true)
        set(value) = prefs.edit().putBoolean("show_correction", value).apply()

    var convert555: Boolean
        get() = prefs.getBoolean("convert_555", true)
        set(value) = prefs.edit().putBoolean("convert_555", value).apply()

    // === Overlay ===
    var floatingButtonAlpha: Float
        get() = prefs.getFloat("fab_alpha", 0.4f)
        set(value) = prefs.edit().putFloat("fab_alpha", value).apply()

    fun canUseOcrToday(): Boolean {
        val today = java.time.LocalDate.now().toString()
        if (lastOcrDate != today) {
            todayOcrCount = 0
            lastOcrDate = today
        }
        return todayOcrCount < dailyOcrLimit
    }

    fun incrementOcrCount() {
        todayOcrCount += 1
    }
}
