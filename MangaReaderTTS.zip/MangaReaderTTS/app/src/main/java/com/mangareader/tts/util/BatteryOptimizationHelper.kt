package com.mangareader.tts.util

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings

object BatteryOptimizationHelper {

    fun isIgnoringBatteryOptimizations(context: Context): Boolean {
        val pm = context.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(context.packageName)
    }

    fun requestIgnoreBatteryOptimizations(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                    data = Uri.parse("package:${context.packageName}")
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                context.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
    }

    fun getManufacturerGuide(): String {
        val manufacturer = Build.MANUFACTURER.lowercase()
        return when {
            manufacturer.contains("xiaomi") || manufacturer.contains("redmi") || manufacturer.contains("poco") ->
                "Xiaomi/Redmi/POCO:\n1. Settings → Apps → Manga Reader TTS → Battery saver → No restrictions\n2. Settings → Apps → Manage apps → Autostart → เปิด"

            manufacturer.contains("oppo") || manufacturer.contains("realme") ->
                "Oppo/Realme:\n1. Settings → Battery → App battery management → Manga Reader TTS → Don't optimize\n2. เปิด Autostart"

            manufacturer.contains("vivo") ->
                "Vivo:\n1. Settings → Battery → Background power consumption → อนุญาต\n2. iManager → App manager → Autostart"

            manufacturer.contains("huawei") || manufacturer.contains("honor") ->
                "Huawei/Honor:\n1. Settings → Apps → Manga Reader TTS → Battery → App launch → Manual\n2. เปิด Autostart + Secondary launch"

            manufacturer.contains("samsung") ->
                "Samsung:\n1. Settings → Apps → Manga Reader TTS → Battery → Unrestricted\n2. อย่าใส่ใน Sleeping apps / Deep sleeping apps"

            else ->
                "ทั่วไป:\nSettings → Apps → Manga Reader TTS → Battery → Unrestricted / Don't optimize"
        }
    }
}
