package com.mangareader.tts.ocr

import android.content.Context
import android.graphics.Bitmap
import com.mangareader.tts.capture.ImagePreprocessor
import com.mangareader.tts.data.AppSettings

class OcrRepository(context: Context) {

    private val cloudEngine = GoogleVisionOcr()
    private val offlineEngine = TesseractOcr(context)

    /**
     * เลือก engine อัตโนมัติ:
     * - ถ้าผู้ใช้เลือก offline → ใช้ Tesseract
     * - ถ้าเลือก cloud แต่ไม่มี API Key / proxy → ถอยไป offline
     * - ถ้ามี API Key → ใช้ cloud
     */
    private fun currentEngine(): OcrEngine {
        val preferCloud = AppSettings.ocrEngine == "cloud"
        val hasCloudKey = AppSettings.googleVisionApiKey.isNotBlank() || AppSettings.proxyUrl.isNotBlank()

        return when {
            preferCloud && hasCloudKey -> cloudEngine
            offlineEngine.isAvailable() -> offlineEngine
            hasCloudKey -> cloudEngine
            else -> offlineEngine // แม้ยังไม่มี tessdata ก็คืน offline เพื่อให้ error ชัดเจน
        }
    }

    suspend fun recognize(bitmap: Bitmap): List<TextBlock> {
        val prepared = ImagePreprocessor.prepareForOcr(bitmap)
        val hash = ImagePreprocessor.computeHash(prepared)

        // เช็ค cache ก่อน
        OcrCache.get(hash)?.let { return it }

        val engine = currentEngine()

        if (!engine.isAvailable()) {
            val msg = when (engine) {
                is GoogleVisionOcr -> "ยังไม่มี API Key — สลับไปโหมด Offline หรือใส่ Key ใน Settings"
                else -> "โหมด Offline ยังไม่พร้อม: กรุณาวางไฟล์ tha.traineddata ในโฟลเดอร์ tessdata ของแอป (ดู README)"
            }
            throw IllegalStateException(msg)
        }

        val result = engine.recognize(prepared)
        OcrCache.put(hash, result)

        if (prepared != bitmap) {
            prepared.recycle()
        }
        return result
    }
}
