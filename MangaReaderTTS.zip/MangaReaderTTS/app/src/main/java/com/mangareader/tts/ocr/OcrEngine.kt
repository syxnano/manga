package com.mangareader.tts.ocr

import android.graphics.Bitmap
import android.graphics.Rect

data class TextBlock(
    val text: String,
    val boundingBox: Rect,
    val confidence: Float = 1.0f
)

interface OcrEngine {
    suspend fun recognize(bitmap: Bitmap, language: String = "th"): List<TextBlock>
    fun isAvailable(): Boolean
    fun getName(): String
}
