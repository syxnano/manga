package com.mangareader.tts.capture

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.graphics.Rect
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.HandlerThread
import android.util.DisplayMetrics
import android.view.WindowManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume

/**
 * จับภาพหน้าจอแบบ on-demand เท่านั้น
 * ไม่บันทึกไฟล์ และคืนทรัพยากรทันทีหลังใช้
 */
class ScreenCaptureManager(private val context: Context) {

    private val mediaProjectionManager =
        context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var handlerThread: HandlerThread? = null
    private var handler: Handler? = null

    private var screenWidth = 0
    private var screenHeight = 0
    private var screenDensity = 0

    init {
        val wm = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        screenWidth = metrics.widthPixels
        screenHeight = metrics.heightPixels
        screenDensity = metrics.densityDpi
    }

    /**
     * เริ่ม session จากผลลัพธ์ของ MediaProjection permission
     * บน Android 14+ ต้องขอใหม่ทุกครั้ง
     */
    fun startSession(resultCode: Int, data: Intent): Boolean {
        return try {
            stopSession()
            mediaProjection = mediaProjectionManager.getMediaProjection(resultCode, data)
            mediaProjection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() {
                    stopSession()
                }
            }, null)

            handlerThread = HandlerThread("ScreenCapture").also { it.start() }
            handler = Handler(handlerThread!!.looper)
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    /**
     * จับภาพครั้งเดียว (ทั้งหน้าจอหรือเฉพาะ region)
     * คืน Bitmap ที่อยู่ในหน่วยความจำ — ต้อง recycle เองหลังใช้
     */
    suspend fun captureOnce(region: Rect? = null): Bitmap? = withContext(Dispatchers.IO) {
        val projection = mediaProjection ?: return@withContext null

        suspendCancellableCoroutine { cont ->
            try {
                imageReader = ImageReader.newInstance(
                    screenWidth, screenHeight,
                    PixelFormat.RGBA_8888, 2
                )

                virtualDisplay = projection.createVirtualDisplay(
                    "MangaCapture",
                    screenWidth, screenHeight, screenDensity,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader!!.surface,
                    null, handler
                )

                imageReader!!.setOnImageAvailableListener({ reader ->
                    var image: Image? = null
                    try {
                        image = reader.acquireLatestImage()
                        if (image != null) {
                            val bitmap = imageToBitmap(image)
                            val result = if (region != null && bitmap != null) {
                                cropBitmap(bitmap, region).also {
                                    if (it != bitmap) bitmap.recycle()
                                }
                            } else {
                                bitmap
                            }
                            cont.resume(result)
                        } else {
                            cont.resume(null)
                        }
                    } catch (e: Exception) {
                        e.printStackTrace()
                        cont.resume(null)
                    } finally {
                        image?.close()
                        // คืนทรัพยากรทันที
                        cleanupCaptureResources()
                    }
                }, handler)

                cont.invokeOnCancellation {
                    cleanupCaptureResources()
                }
            } catch (e: Exception) {
                e.printStackTrace()
                cleanupCaptureResources()
                cont.resume(null)
            }
        }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        val planes = image.planes
        val buffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * screenWidth

        val bitmap = Bitmap.createBitmap(
            screenWidth + rowPadding / pixelStride,
            screenHeight,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)
        return if (rowPadding == 0) {
            bitmap
        } else {
            Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight).also {
                if (it != bitmap) bitmap.recycle()
            }
        }
    }

    private fun cropBitmap(source: Bitmap, region: Rect): Bitmap {
        val left = region.left.coerceIn(0, source.width)
        val top = region.top.coerceIn(0, source.height)
        val width = region.width().coerceAtMost(source.width - left)
        val height = region.height().coerceAtMost(source.height - top)
        return Bitmap.createBitmap(source, left, top, width, height)
    }

    private fun cleanupCaptureResources() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {
        }
    }

    fun stopSession() {
        cleanupCaptureResources()
        mediaProjection?.stop()
        mediaProjection = null
        handlerThread?.quitSafely()
        handlerThread = null
        handler = null
    }

    fun isSessionActive(): Boolean = mediaProjection != null

    fun getScreenSize(): Pair<Int, Int> = screenWidth to screenHeight
}
