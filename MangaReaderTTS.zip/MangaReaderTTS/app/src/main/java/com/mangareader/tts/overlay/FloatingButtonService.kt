package com.mangareader.tts.overlay

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.graphics.Rect
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.mangareader.tts.MainActivity
import com.mangareader.tts.MangaReaderApp
import com.mangareader.tts.R
import com.mangareader.tts.capture.ScreenCaptureManager
import com.mangareader.tts.data.AppSettings
import com.mangareader.tts.ocr.OcrRepository
import com.mangareader.tts.ocr.TextBlock
import com.mangareader.tts.text.ReadingOrder
import com.mangareader.tts.text.TextProcessor
import com.mangareader.tts.tts.TtsManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Foreground Service ที่แสดงปุ่มลอย + จัดการการจับภาพ + OCR + TTS
 */
class FloatingButtonService : Service() {

    private lateinit var windowManager: WindowManager
    private var floatingView: View? = null
    private var highlightView: HighlightOverlayView? = null

    private var params: WindowManager.LayoutParams? = null
    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private lateinit var captureManager: ScreenCaptureManager
    private lateinit var ocrRepository: OcrRepository
    private lateinit var ttsManager: TtsManager

    private var currentMode = SelectionMode.TAP
    private var isTransparent = false
    private var lastBlocks: List<TextBlock> = emptyList()

    // MediaProjection result (ส่งมาจาก MainActivity)
    private var projectionResultCode: Int = 0
    private var projectionData: Intent? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        captureManager = ScreenCaptureManager(this)
        ocrRepository = OcrRepository(this)
        ttsManager = TtsManager(this)

        ttsManager.onUtteranceDone = { /* สามารถไฮไลต์บับเบิลถัดไปได้ */ }
        ttsManager.onQueueFinished = {
            Toast.makeText(this, "อ่านจบแล้ว", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                projectionResultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                projectionData = intent.getParcelableExtra(EXTRA_DATA)
                startForeground(NOTIFICATION_ID, createNotification())
                showFloatingButton()
                projectionData?.let {
                    captureManager.startSession(projectionResultCode, it)
                }
            }
            ACTION_STOP -> {
                stopSelf()
            }
            ACTION_UPDATE_MODE -> {
                currentMode = when (currentMode) {
                    SelectionMode.TAP -> SelectionMode.CROP
                    SelectionMode.CROP -> SelectionMode.FULL_SCREEN
                    SelectionMode.FULL_SCREEN -> SelectionMode.TAP
                }
                Toast.makeText(this, "โหมด: ${currentMode.name}", Toast.LENGTH_SHORT).show()
            }
        }
        return START_STICKY
    }

    private fun createNotification(): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, MangaReaderApp.CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(getString(R.string.notification_text))
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pending)
            .setOngoing(true)
            .setSilent(true)
            .build()
    }

    private fun showFloatingButton() {
        if (floatingView != null) return

        val button = ImageButton(this).apply {
            setImageResource(android.R.drawable.ic_btn_speak_now)
            setBackgroundColor(0xAA6200EE.toInt())
            setPadding(24, 24, 24, 24)
            alpha = 0.9f
        }

        val container = FrameLayout(this).apply {
            addView(button)
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 300
        }

        button.setOnTouchListener { v, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params!!.x
                    initialY = params!!.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    v.alpha = 1.0f
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params!!.x = initialX + (event.rawX - initialTouchX).toInt()
                    params!!.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager.updateViewLayout(floatingView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val dx = event.rawX - initialTouchX
                    val dy = event.rawY - initialTouchY
                    if (dx * dx + dy * dy < 100) {
                        // ถือว่าเป็นการแตะ
                        onFloatingButtonClicked()
                    }
                    // ทำให้โปร่งแสงหลัง 3 วินาที
                    v.postDelayed({ v.alpha = AppSettings.floatingButtonAlpha }, 3000)
                    true
                }
                else -> false
            }
        }

        // Long press = สลับโหมด
        button.setOnLongClickListener {
            currentMode = when (currentMode) {
                SelectionMode.TAP -> SelectionMode.CROP
                SelectionMode.CROP -> SelectionMode.FULL_SCREEN
                SelectionMode.FULL_SCREEN -> SelectionMode.TAP
            }
            Toast.makeText(this, "โหมด: ${currentMode.name}", Toast.LENGTH_SHORT).show()
            true
        }

        floatingView = container
        windowManager.addView(floatingView, params)
    }

    private fun onFloatingButtonClicked() {
        if (!captureManager.isSessionActive()) {
            Toast.makeText(this, "กรุณาอนุญาตการจับภาพหน้าจอก่อน (เปิดจากแอปหลัก)", Toast.LENGTH_LONG).show()
            return
        }

        when (currentMode) {
            SelectionMode.FULL_SCREEN -> captureAndRead(null)
            SelectionMode.TAP -> {
                // ใช้ตำแหน่งปุ่มเป็นจุดประมาณ (จริง ๆ ควรมี overlay เลือกจุด)
                Toast.makeText(this, "โหมด TAP: จับทั้งหน้าจอแล้วหาข้อความใกล้จุดปุ่ม", Toast.LENGTH_SHORT).show()
                captureAndRead(null) // ขยายในอนาคต
            }
            SelectionMode.CROP -> {
                // โหมด CROP ต้องมี UI ลากกรอบ — ตอนนี้ใช้ full เป็น placeholder
                Toast.makeText(this, "โหมด CROP ยังเป็น prototype (ใช้ full screen แทน)", Toast.LENGTH_SHORT).show()
                captureAndRead(null)
            }
        }
    }

    private fun captureAndRead(region: Rect?) {
        serviceScope.launch {
            try {
                Toast.makeText(this@FloatingButtonService, "กำลังจับภาพและ OCR...", Toast.LENGTH_SHORT).show()
                val bitmap = captureManager.captureOnce(region)
                if (bitmap == null) {
                    Toast.makeText(this@FloatingButtonService, "จับภาพไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val blocks = ocrRepository.recognize(bitmap)
                bitmap.recycle()

                if (blocks.isEmpty()) {
                    Toast.makeText(this@FloatingButtonService, "ไม่พบข้อความ", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                lastBlocks = ReadingOrder.sort(blocks)
                showHighlights(lastBlocks)

                val sentences = TextProcessor.process(lastBlocks)
                if (sentences.isEmpty()) {
                    Toast.makeText(this@FloatingButtonService, "ไม่มีข้อความให้อ่านหลังกรอง", Toast.LENGTH_SHORT).show()
                    return@launch
                }

                // ถ้าเปิด correction dialog จะส่งกลับไป MainActivity (ขยายในอนาคต)
                ttsManager.speak(sentences)

            } catch (e: Exception) {
                e.printStackTrace()
                Toast.makeText(this@FloatingButtonService, "เกิดข้อผิดพลาด: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showHighlights(blocks: List<TextBlock>) {
        // ลบของเก่า
        highlightView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }

        highlightView = HighlightOverlayView(this, blocks).also { view ->
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION")
                    WindowManager.LayoutParams.TYPE_PHONE,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            )
            windowManager.addView(view, lp)

            // หายไปหลัง 8 วินาที
            view.postDelayed({
                try { windowManager.removeView(view) } catch (_: Exception) {}
                highlightView = null
            }, 8000)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        ttsManager.shutdown()
        captureManager.stopSession()
        floatingView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        highlightView?.let {
            try { windowManager.removeView(it) } catch (_: Exception) {}
        }
        floatingView = null
        highlightView = null
    }

    companion object {
        const val ACTION_START = "com.mangareader.tts.START"
        const val ACTION_STOP = "com.mangareader.tts.STOP"
        const val ACTION_UPDATE_MODE = "com.mangareader.tts.UPDATE_MODE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "data"
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context, resultCode: Int, data: Intent) {
            val intent = Intent(context, FloatingButtonService::class.java).apply {
                action = ACTION_START
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_DATA, data)
            }
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, FloatingButtonService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }
}
